import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:test_flutter_project/view/view.dart';
import 'package:test_flutter_project/viewmodel/view_model.dart';

part 'app_route.dart';
